import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Home, ArrowLeft } from "lucide-react";

const NotFound = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background texture-paper pt-24">
      <div className="text-center px-4">
        {/* Decorative mandala */}
        <div className="w-32 h-32 mx-auto mb-8 opacity-20">
          <svg viewBox="0 0 100 100" className="w-full h-full animate-spin" style={{ animationDuration: '30s' }}>
            <circle cx="50" cy="50" r="45" fill="none" stroke="hsl(var(--secondary))" strokeWidth="1"/>
            <circle cx="50" cy="50" r="35" fill="none" stroke="hsl(var(--secondary))" strokeWidth="1"/>
            <circle cx="50" cy="50" r="25" fill="none" stroke="hsl(var(--secondary))" strokeWidth="1"/>
            <circle cx="50" cy="50" r="15" fill="none" stroke="hsl(var(--secondary))" strokeWidth="1"/>
          </svg>
        </div>

        <h1 className="font-display text-6xl md:text-8xl font-bold gradient-gold-text mb-4">404</h1>
        <h2 className="font-display text-2xl md:text-3xl font-bold text-foreground mb-4">
          Page Not Found
        </h2>
        <p className="text-muted-foreground mb-8 max-w-md mx-auto">
          The page you're looking for seems to have wandered off. Let us guide you back to our celebrations.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/">
            <Button variant="gold" size="lg">
              <Home className="w-5 h-5" />
              Return Home
            </Button>
          </Link>
          <Button variant="elegant" size="lg" onClick={() => window.history.back()}>
            <ArrowLeft className="w-5 h-5" />
            Go Back
          </Button>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
