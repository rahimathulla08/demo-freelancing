import { useState } from "react";
import { X, ZoomIn } from "lucide-react";

const galleryImages = [
  {
    src: "https://images.unsplash.com/photo-1519741497674-611481863552?w=800&h=600&fit=crop",
    alt: "Traditional wedding ceremony",
    category: "Wedding",
    span: "col-span-2 row-span-2",
  },
  {
    src: "https://images.unsplash.com/photo-1547153760-18fc86324498?w=600&h=400&fit=crop",
    alt: "Classical dance performance",
    category: "Dance",
    span: "col-span-1 row-span-1",
  },
  {
    src: "https://images.unsplash.com/photo-1605810230434-7631ac76ec81?w=600&h=400&fit=crop",
    alt: "Diwali celebration",
    category: "Festival",
    span: "col-span-1 row-span-1",
  },
  {
    src: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?w=600&h=800&fit=crop",
    alt: "Temple decoration",
    category: "Temple",
    span: "col-span-1 row-span-2",
  },
  {
    src: "https://images.unsplash.com/photo-1583089892943-e02e5b017b6a?w=600&h=400&fit=crop",
    alt: "Mandap decoration",
    category: "Decoration",
    span: "col-span-1 row-span-1",
  },
  {
    src: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?w=800&h=400&fit=crop",
    alt: "Engagement ceremony",
    category: "Engagement",
    span: "col-span-2 row-span-1",
  },
  {
    src: "https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?w=600&h=400&fit=crop",
    alt: "Floral arrangements",
    category: "Decoration",
    span: "col-span-1 row-span-1",
  },
  {
    src: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=600&h=400&fit=crop",
    alt: "Corporate event",
    category: "Corporate",
    span: "col-span-1 row-span-1",
  },
  {
    src: "https://images.unsplash.com/photo-1604017011826-d3b4c23f8914?w=600&h=600&fit=crop",
    alt: "Henna ceremony",
    category: "Wedding",
    span: "col-span-1 row-span-1",
  },
  {
    src: "https://images.unsplash.com/photo-1494955464529-790512c65305?w=600&h=400&fit=crop",
    alt: "Cultural performance",
    category: "Performance",
    span: "col-span-1 row-span-1",
  },
];

const categories = ["All", "Wedding", "Dance", "Festival", "Temple", "Decoration", "Corporate"];

const Gallery = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredImages = activeCategory === "All" 
    ? galleryImages 
    : galleryImages.filter(img => img.category === activeCategory);

  return (
    <div className="min-h-screen pt-24">
      {/* Hero */}
      <section className="py-16 bg-gradient-to-br from-background via-muted to-background relative overflow-hidden">
        <div className="absolute inset-0 mandala-bg opacity-30" />
        <div className="container mx-auto px-4 text-center relative z-10">
          <span className="inline-block px-4 py-1 rounded-full bg-secondary/10 text-secondary text-sm font-medium mb-4">
            Our Portfolio
          </span>
          <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            <span className="text-foreground">Event</span>{" "}
            <span className="gradient-gold-text">Gallery</span>
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            A glimpse into the beautiful celebrations we've had the honor of creating.
          </p>
        </div>
      </section>

      {/* Filter */}
      <section className="py-8 bg-card border-b border-border">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center gap-3">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-5 py-2 rounded-full font-medium transition-all duration-300 ${
                  activeCategory === category
                    ? "bg-gradient-to-r from-secondary to-gold-dark text-secondary-foreground shadow-gold"
                    : "bg-muted text-muted-foreground hover:bg-secondary/10 hover:text-secondary"
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 auto-rows-[200px]">
            {filteredImages.map((image, index) => (
              <div
                key={index}
                className={`group relative overflow-hidden rounded-2xl cursor-pointer border-2 border-secondary/10 hover:border-secondary/40 transition-all duration-500 ${image.span}`}
                onClick={() => setSelectedImage(image.src)}
              >
                <img
                  src={image.src}
                  alt={image.alt}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                
                {/* Overlay with sepia tint */}
                <div className="absolute inset-0 bg-gradient-to-t from-primary/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                
                {/* Gold vignette effect */}
                <div className="absolute inset-0 border-8 border-transparent group-hover:border-secondary/20 transition-all duration-300 rounded-2xl" />
                
                {/* Content */}
                <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                  <span className="inline-block px-3 py-1 rounded-full bg-secondary/90 text-secondary-foreground text-xs font-medium mb-2">
                    {image.category}
                  </span>
                  <p className="text-primary-foreground text-sm font-medium">{image.alt}</p>
                </div>

                {/* Zoom icon */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-14 h-14 rounded-full bg-secondary/80 flex items-center justify-center shadow-gold">
                    <ZoomIn className="w-6 h-6 text-secondary-foreground" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Lightbox */}
      {selectedImage && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/95 backdrop-blur-xl p-4"
          onClick={() => setSelectedImage(null)}
        >
          <button
            className="absolute top-6 right-6 w-12 h-12 rounded-full bg-secondary flex items-center justify-center hover:bg-secondary/80 transition-colors"
            onClick={() => setSelectedImage(null)}
          >
            <X className="w-6 h-6 text-secondary-foreground" />
          </button>
          <img
            src={selectedImage.replace("w=600", "w=1200").replace("w=800", "w=1200")}
            alt="Gallery fullscreen"
            className="max-w-full max-h-[90vh] object-contain rounded-2xl border-4 border-secondary/30 shadow-gold"
          />
        </div>
      )}
    </div>
  );
};

export default Gallery;
