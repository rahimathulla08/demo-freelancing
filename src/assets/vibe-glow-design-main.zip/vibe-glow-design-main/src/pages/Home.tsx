import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import FloatingDiya from "@/components/decorative/FloatingDiya";
import { 
  Sparkles, Heart, Music, Users, Camera, Crown, 
  ArrowRight, Star, Quote 
} from "lucide-react";

const categories = [
  {
    icon: Heart,
    title: "Wedding Ceremony",
    description: "Sacred rituals with timeless elegance",
    image: "https://images.unsplash.com/photo-1519741497674-611481863552?w=600&h=400&fit=crop",
  },
  {
    icon: Music,
    title: "Traditional Dance",
    description: "Classical performances that mesmerize",
    image: "https://images.unsplash.com/photo-1547153760-18fc86324498?w=600&h=400&fit=crop",
  },
  {
    icon: Sparkles,
    title: "Cultural Festivals",
    description: "Diwali, Holi, Navratri & more",
    image: "https://images.unsplash.com/photo-1605810230434-7631ac76ec81?w=600&h=400&fit=crop",
  },
  {
    icon: Crown,
    title: "Temple Events",
    description: "Divine ceremonies & rituals",
    image: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?w=600&h=400&fit=crop",
  },
];

const testimonials = [
  {
    quote: "They brought our traditional wedding dreams to life with such elegance and attention to detail.",
    author: "Priya & Rahul Sharma",
    event: "Wedding Ceremony",
  },
  {
    quote: "The Diwali celebration they organized for our company was absolutely magical.",
    author: "Arun Mehta",
    event: "Corporate Diwali",
  },
];

const Home = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-background via-muted to-background">
        <FloatingDiya />
        
        {/* Background texture */}
        <div className="absolute inset-0 mandala-bg opacity-50" />
        
        {/* Gradient overlays */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-secondary/10 rounded-full blur-[150px]" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary/10 rounded-full blur-[150px]" />

        <div className="relative z-10 container mx-auto px-4 text-center pt-20">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-secondary/10 border border-secondary/30 rounded-full px-5 py-2 mb-8">
            <Sparkles className="w-4 h-4 text-secondary" />
            <span className="text-sm text-foreground font-medium">Celebrating Indian Traditions Since 2010</span>
          </div>

          {/* Main heading */}
          <h1 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-tight mb-6">
            <span className="text-foreground">Celebrate Moments</span>
            <br />
            <span className="gradient-gold-text text-shadow-gold">Rooted in Tradition</span>
          </h1>

          {/* Subheading */}
          <p className="font-elegant text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto mb-4 italic">
            Where heritage meets celebration
          </p>
          <p className="text-muted-foreground max-w-xl mx-auto mb-10">
            We craft unforgettable cultural experiences that honor your traditions while creating memories for generations to come.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16">
            <Link to="/contact">
              <Button variant="gold" size="xl" className="group">
                Plan Your Event
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
            <Link to="/gallery">
              <Button variant="elegant" size="xl">
                View Gallery
              </Button>
            </Link>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-8 max-w-lg mx-auto">
            <div className="text-center">
              <div className="font-display text-3xl md:text-4xl font-bold gradient-gold-text">500+</div>
              <div className="text-sm text-muted-foreground">Events</div>
            </div>
            <div className="text-center">
              <div className="font-display text-3xl md:text-4xl font-bold gradient-maroon-text">15+</div>
              <div className="text-sm text-muted-foreground">Years</div>
            </div>
            <div className="text-center">
              <div className="font-display text-3xl md:text-4xl font-bold gradient-gold-text">50K+</div>
              <div className="text-sm text-muted-foreground">Guests</div>
            </div>
          </div>
        </div>

        {/* Decorative bottom curve */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full">
            <path d="M0 100L60 90C120 80 240 60 360 55C480 50 600 60 720 65C840 70 960 70 1080 65C1200 60 1320 50 1380 45L1440 40V100H0Z" fill="hsl(var(--card))"/>
          </svg>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-24 bg-card paisley-pattern">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="inline-block px-4 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
              Our Specialties
            </span>
            <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
              <span className="text-foreground">Cultural</span>{" "}
              <span className="gradient-gold-text">Celebrations</span>
            </h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              From sacred ceremonies to grand festivities, we bring your traditions to life.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((category, index) => (
              <Link to="/events" key={category.title}>
                <div className="group relative overflow-hidden rounded-2xl border-2 border-secondary/20 bg-background hover:border-secondary/50 transition-all duration-500 hover:-translate-y-2 hover:shadow-gold">
                  <div className="aspect-[4/3] overflow-hidden">
                    <img
                      src={category.image}
                      alt={category.title}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-primary/90 via-primary/40 to-transparent" />
                  </div>
                  
                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-secondary to-gold-dark flex items-center justify-center mb-3 shadow-gold">
                      <category.icon className="w-6 h-6 text-secondary-foreground" />
                    </div>
                    <h3 className="font-display text-xl font-semibold text-primary-foreground mb-1">
                      {category.title}
                    </h3>
                    <p className="text-primary-foreground/80 text-sm">
                      {category.description}
                    </p>
                  </div>

                  {/* Gold corner accent */}
                  <div className="absolute top-0 right-0 w-16 h-16 overflow-hidden">
                    <div className="absolute top-2 right-2 w-2 h-8 bg-secondary/50 rotate-45 origin-top-right" />
                  </div>
                </div>
              </Link>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link to="/events">
              <Button variant="maroon" size="lg">
                Explore All Events
                <ArrowRight className="w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* About Preview */}
      <section className="py-24 bg-background texture-paper relative overflow-hidden">
        <div className="absolute top-10 left-10 w-40 h-40 opacity-10">
          <svg viewBox="0 0 100 100" className="w-full h-full">
            <circle cx="50" cy="50" r="45" fill="none" stroke="hsl(var(--secondary))" strokeWidth="1" strokeDasharray="4,4"/>
          </svg>
        </div>

        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="inline-block px-4 py-1 rounded-full bg-secondary/10 text-secondary text-sm font-medium mb-4">
                Our Story
              </span>
              <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold mb-6">
                <span className="text-foreground">Preserving </span>
                <span className="gradient-maroon-text">Heritage</span>
              </h2>
              <p className="font-elegant text-xl text-muted-foreground italic mb-4">
                "Every celebration tells a story, every ritual carries meaning"
              </p>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                For over 15 years, we have been dedicated to creating cultural experiences that honor traditions while embracing modern elegance. Our team of experts understands the sacred significance of every ritual, ensuring your celebrations are both authentic and unforgettable.
              </p>
              <Link to="/about">
                <Button variant="elegant">
                  Learn Our Story
                  <ArrowRight className="w-5 h-5" />
                </Button>
              </Link>
            </div>

            <div className="relative">
              <div className="aspect-[4/3] rounded-2xl overflow-hidden border-4 border-secondary/30 shadow-gold">
                <img
                  src="https://images.unsplash.com/photo-1583089892943-e02e5b017b6a?w=800&h=600&fit=crop"
                  alt="Traditional celebration"
                  className="w-full h-full object-cover"
                />
              </div>
              {/* Decorative frame corners */}
              <div className="absolute -top-4 -left-4 w-12 h-12 border-t-4 border-l-4 border-secondary rounded-tl-lg" />
              <div className="absolute -bottom-4 -right-4 w-12 h-12 border-b-4 border-r-4 border-secondary rounded-br-lg" />
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-gradient-to-br from-primary to-primary/90 text-primary-foreground relative overflow-hidden">
        <div className="absolute inset-0 mandala-bg opacity-10" />
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-16">
            <span className="inline-block px-4 py-1 rounded-full bg-secondary/20 text-secondary text-sm font-medium mb-4">
              Testimonials
            </span>
            <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
              <span className="text-primary-foreground">What Our</span>{" "}
              <span className="text-secondary">Clients Say</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-primary-foreground/5 backdrop-blur-sm rounded-2xl p-8 border border-secondary/20">
                <Quote className="w-10 h-10 text-secondary mb-4" />
                <p className="font-elegant text-xl italic text-primary-foreground/90 mb-6">
                  "{testimonial.quote}"
                </p>
                <div className="h-px bg-gradient-to-r from-transparent via-secondary to-transparent mb-4" />
                <div>
                  <div className="font-semibold text-secondary">{testimonial.author}</div>
                  <div className="text-primary-foreground/60 text-sm">{testimonial.event}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-r from-primary via-accent to-secondary relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20viewBox%3D%220%200%2060%2060%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%3Cg%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%3Cg%20fill%3D%22%23ffffff%22%20fill-opacity%3D%220.05%22%3E%3Cpath%20d%3D%22M36%2034v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6%2034v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6%204V0H4v4H0v2h4v4h2V6h4V4H6z%22%2F%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E')] opacity-50" />
        
        <div className="container mx-auto px-4 text-center relative z-10">
          <h2 className="font-display text-3xl md:text-4xl lg:text-6xl font-bold text-primary-foreground mb-6">
            Let's Bring Your
            <br />
            <span className="text-secondary-foreground">Tradition to Life</span>
          </h2>
          <p className="text-primary-foreground/90 text-lg max-w-2xl mx-auto mb-10">
            Ready to create an unforgettable cultural celebration? Our experts are here to make your vision a reality.
          </p>
          <Link to="/contact">
            <Button variant="gold" size="xl" className="animate-glow-pulse">
              Start Planning Today
              <ArrowRight className="w-6 h-6" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;
