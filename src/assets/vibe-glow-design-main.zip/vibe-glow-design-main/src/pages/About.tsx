import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, Award, Users, Calendar, Heart } from "lucide-react";

const stats = [
  { icon: Calendar, value: "15+", label: "Years of Experience" },
  { icon: Award, value: "500+", label: "Events Organized" },
  { icon: Users, value: "50K+", label: "Happy Guests" },
  { icon: Heart, value: "100%", label: "Client Satisfaction" },
];

const team = [
  {
    name: "Ananya Sharma",
    role: "Founder & Creative Director",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop",
  },
  {
    name: "Rajesh Patel",
    role: "Event Operations Head",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop",
  },
  {
    name: "Priya Menon",
    role: "Cultural Consultant",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&h=400&fit=crop",
  },
  {
    name: "Vikram Singh",
    role: "Decoration Specialist",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop",
  },
];

const About = () => {
  return (
    <div className="min-h-screen pt-24">
      {/* Hero */}
      <section className="py-16 bg-gradient-to-br from-background via-muted to-background relative overflow-hidden">
        <div className="absolute inset-0 texture-paper opacity-50" />
        <div className="container mx-auto px-4 text-center relative z-10">
          <span className="inline-block px-4 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            About Us
          </span>
          <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            <span className="text-foreground">Our</span>{" "}
            <span className="gradient-maroon-text">Story</span>
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Preserving traditions while creating unforgettable celebrations since 2010.
          </p>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 bg-card paisley-pattern">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <div className="aspect-square rounded-2xl overflow-hidden border-4 border-secondary/30 shadow-gold">
                <img
                  src="https://images.unsplash.com/photo-1583089892943-e02e5b017b6a?w=800&h=800&fit=crop"
                  alt="Our journey"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 w-40 h-40 rounded-2xl overflow-hidden border-4 border-background shadow-gold">
                <img
                  src="https://images.unsplash.com/photo-1519741497674-611481863552?w=300&h=300&fit=crop"
                  alt="Traditional celebration"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            <div>
              <h2 className="font-display text-3xl md:text-4xl font-bold mb-6">
                <span className="text-foreground">Where</span>{" "}
                <span className="gradient-gold-text">Heritage Meets Celebration</span>
              </h2>
              
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p className="font-elegant text-xl italic text-foreground/80">
                  "Every tradition carries a story, every ritual holds meaning."
                </p>
                <p>
                  Founded in 2010 by Ananya Sharma, Sanskritik Cultural Events was born from a passion for preserving India's rich cultural heritage while adapting to modern sensibilities.
                </p>
                <p>
                  What started as a small team organizing local temple events has grown into one of India's most trusted cultural event management companies. We've had the privilege of orchestrating over 500 celebrations, from intimate puja ceremonies to grand destination weddings.
                </p>
                <p>
                  Our team comprises cultural consultants, traditional artists, and event professionals who share a common vision: to create celebrations that honor your roots while reflecting your unique story.
                </p>
              </div>

              <div className="h-px bg-gradient-to-r from-secondary via-gold-dark to-transparent my-8" />

              <div className="grid grid-cols-2 gap-4">
                {stats.slice(0, 2).map((stat) => (
                  <div key={stat.label} className="text-center p-4 rounded-xl bg-background border border-secondary/20">
                    <stat.icon className="w-8 h-8 text-secondary mx-auto mb-2" />
                    <div className="font-display text-2xl font-bold gradient-gold-text">{stat.value}</div>
                    <div className="text-sm text-muted-foreground">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 bg-gradient-to-r from-primary to-accent text-primary-foreground">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <stat.icon className="w-10 h-10 text-secondary mx-auto mb-3" />
                <div className="font-display text-4xl font-bold mb-1">{stat.value}</div>
                <div className="text-primary-foreground/80 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="inline-block px-4 py-1 rounded-full bg-secondary/10 text-secondary text-sm font-medium mb-4">
              Our Team
            </span>
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
              <span className="text-foreground">The People Behind</span>{" "}
              <span className="gradient-gold-text">The Magic</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member) => (
              <div key={member.name} className="group text-center">
                <div className="relative mb-4">
                  <div className="aspect-square rounded-full overflow-hidden border-4 border-secondary/20 mx-auto max-w-[200px] group-hover:border-secondary transition-colors duration-300 group-hover:shadow-gold">
                    <img
                      src={member.image}
                      alt={member.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  {/* Decorative ring */}
                  <div className="absolute inset-0 rounded-full border-2 border-dashed border-secondary/30 scale-110 opacity-0 group-hover:opacity-100 transition-opacity duration-300 max-w-[220px] mx-auto" />
                </div>
                <h3 className="font-display text-lg font-bold text-foreground">{member.name}</h3>
                <p className="text-muted-foreground text-sm">{member.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-card texture-paper">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-8">
              <span className="text-foreground">Our</span>{" "}
              <span className="gradient-maroon-text">Values</span>
            </h2>

            <div className="grid md:grid-cols-3 gap-8">
              {[
                { title: "Authenticity", desc: "Honoring traditions in their truest form" },
                { title: "Excellence", desc: "Perfection in every detail, every time" },
                { title: "Heart", desc: "Creating celebrations filled with love and joy" },
              ].map((value) => (
                <div key={value.title} className="p-6 rounded-2xl bg-background border-2 border-secondary/20 hover:border-secondary/50 hover:shadow-gold transition-all duration-300">
                  <h3 className="font-display text-xl font-bold text-secondary mb-2">{value.title}</h3>
                  <p className="text-muted-foreground">{value.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-secondary via-gold-dark to-accent text-secondary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
            Ready to Work With Us?
          </h2>
          <p className="text-secondary-foreground/80 mb-8 max-w-xl mx-auto">
            Let's create a celebration that tells your story.
          </p>
          <Link to="/contact">
            <Button variant="maroon" size="xl">
              Get In Touch
              <ArrowRight className="w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default About;
