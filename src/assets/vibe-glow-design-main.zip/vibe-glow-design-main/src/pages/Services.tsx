import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { 
  Palette, Flower2, Music, ScrollText, Users, Drama,
  ArrowRight, Sparkles
} from "lucide-react";

const services = [
  {
    icon: Palette,
    title: "Venue Decoration",
    description: "Transform any space into a cultural masterpiece with traditional motifs, elegant drapes, and authentic décor elements.",
    features: ["Theme Conceptualization", "Floral Arrangements", "Lighting Design", "Entrance Décor"],
  },
  {
    icon: Flower2,
    title: "Mandap & Stage Design",
    description: "Exquisite mandap designs that blend tradition with contemporary aesthetics, creating the perfect sacred space.",
    features: ["Traditional Mandaps", "Floral Canopies", "Stage Backdrops", "Seating Arrangements"],
  },
  {
    icon: Music,
    title: "Traditional Music & Dance",
    description: "Curated performances by professional artists including classical musicians, dancers, and folk performers.",
    features: ["Shehnai & Dhol", "Classical Dance", "Folk Performances", "Devotional Music"],
  },
  {
    icon: ScrollText,
    title: "Ritual & Ceremony Planning",
    description: "Expert coordination of all traditional rituals with experienced priests and ceremony specialists.",
    features: ["Priest Arrangements", "Ritual Coordination", "Puja Materials", "Ceremony Timeline"],
  },
  {
    icon: Users,
    title: "Hospitality & Guest Management",
    description: "Comprehensive guest services ensuring every attendee feels welcomed and cared for.",
    features: ["Guest Reception", "Accommodation Assistance", "Transportation", "RSVP Management"],
  },
  {
    icon: Drama,
    title: "Cultural Performances",
    description: "Engaging cultural programs featuring traditional storytelling, drama, and interactive experiences.",
    features: ["Theater Productions", "Storytelling Sessions", "Interactive Workshops", "Cultural Games"],
  },
];

const Services = () => {
  return (
    <div className="min-h-screen pt-24">
      {/* Hero */}
      <section className="py-16 bg-gradient-to-br from-background via-muted to-background relative overflow-hidden">
        <div className="absolute inset-0 paisley-pattern opacity-30" />
        <div className="container mx-auto px-4 text-center relative z-10">
          <span className="inline-block px-4 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            Our Services
          </span>
          <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            <span className="text-foreground">Complete Event</span>{" "}
            <span className="gradient-maroon-text">Solutions</span>
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            From concept to execution, we provide end-to-end services to make your cultural celebration truly memorable.
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-card">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div
                key={service.title}
                className="group bg-background rounded-2xl border-2 border-secondary/20 p-8 hover:border-secondary/50 hover:shadow-gold transition-all duration-500 hover:-translate-y-2"
              >
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-secondary to-gold-dark flex items-center justify-center mb-6 shadow-gold group-hover:scale-110 transition-transform">
                  <service.icon className="w-8 h-8 text-secondary-foreground" />
                </div>

                <h3 className="font-display text-xl font-bold text-foreground mb-3">
                  {service.title}
                </h3>

                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {service.description}
                </p>

                <ul className="space-y-2">
                  {service.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Sparkles className="w-4 h-4 text-secondary" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-background texture-paper">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <span className="inline-block px-4 py-1 rounded-full bg-secondary/10 text-secondary text-sm font-medium mb-4">
              Our Process
            </span>
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
              <span className="text-foreground">How We</span>{" "}
              <span className="gradient-gold-text">Work</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              { step: "01", title: "Consultation", desc: "Understanding your vision and requirements" },
              { step: "02", title: "Planning", desc: "Detailed planning and vendor coordination" },
              { step: "03", title: "Execution", desc: "Flawless execution of every detail" },
              { step: "04", title: "Celebration", desc: "Creating unforgettable memories" },
            ].map((item, index) => (
              <div key={item.step} className="text-center relative">
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-accent mx-auto mb-4 flex items-center justify-center">
                  <span className="font-display text-2xl font-bold text-primary-foreground">{item.step}</span>
                </div>
                <h3 className="font-display text-lg font-bold text-foreground mb-2">{item.title}</h3>
                <p className="text-muted-foreground text-sm">{item.desc}</p>
                
                {index < 3 && (
                  <div className="hidden md:block absolute top-10 left-[60%] w-[80%] h-0.5 bg-gradient-to-r from-secondary to-transparent" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-secondary via-gold-dark to-accent text-secondary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
            Let's Create Magic Together
          </h2>
          <p className="text-secondary-foreground/80 mb-8 max-w-xl mx-auto">
            Every detail matters. Let us handle the logistics while you enjoy the celebration.
          </p>
          <Link to="/contact">
            <Button variant="maroon" size="xl">
              Request a Quote
              <ArrowRight className="w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Services;
