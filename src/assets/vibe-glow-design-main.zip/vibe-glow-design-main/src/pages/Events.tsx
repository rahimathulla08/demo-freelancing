import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { 
  Heart, Music, Sparkles, Crown, Users, Building2, 
  Star, ArrowRight, Check 
} from "lucide-react";

const events = [
  {
    icon: Heart,
    title: "Wedding Ceremony",
    subtitle: "विवाह समारोह",
    description: "Traditional Hindu, Muslim, Sikh, and Christian wedding ceremonies with authentic rituals, sacred mantras, and blessings.",
    features: ["Mandap Decoration", "Priest Arrangements", "Ritual Coordination", "Bridal Entry Setup"],
    image: "https://images.unsplash.com/photo-1519741497674-611481863552?w=800&h=600&fit=crop",
    color: "from-primary to-primary/70",
  },
  {
    icon: Music,
    title: "Traditional Dance Shows",
    subtitle: "शास्त्रीय नृत्य",
    description: "Mesmerizing classical dance performances including Bharatanatyam, Kathak, Odissi, Kuchipudi, and folk dances.",
    features: ["Professional Artists", "Live Music", "Costume & Makeup", "Stage Design"],
    image: "https://images.unsplash.com/photo-1547153760-18fc86324498?w=800&h=600&fit=crop",
    color: "from-accent to-accent/70",
  },
  {
    icon: Sparkles,
    title: "Cultural Festivals",
    subtitle: "सांस्कृतिक उत्सव",
    description: "Grand celebrations for Diwali, Holi, Navratri, Pongal, Eid, Christmas, and regional festivals.",
    features: ["Theme Decoration", "Cultural Programs", "Traditional Food", "Fireworks & Lighting"],
    image: "https://images.unsplash.com/photo-1605810230434-7631ac76ec81?w=800&h=600&fit=crop",
    color: "from-secondary to-gold-dark",
  },
  {
    icon: Heart,
    title: "Engagement & Pre-Wedding",
    subtitle: "सगाई समारोह",
    description: "Beautiful ceremonies including Roka, Sagai, Mehndi, Sangeet, and Haldi celebrations.",
    features: ["Venue Styling", "Entertainment", "Photography Setup", "Guest Management"],
    image: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?w=800&h=600&fit=crop",
    color: "from-emerald to-emerald/70",
  },
  {
    icon: Building2,
    title: "Corporate Cultural Events",
    subtitle: "कॉर्पोरेट आयोजन",
    description: "Cultural programs for corporate celebrations, team building, and diversity events.",
    features: ["Theme Planning", "Artist Coordination", "AV Setup", "Catering Services"],
    image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&h=600&fit=crop",
    color: "from-navy to-primary",
  },
  {
    icon: Crown,
    title: "Temple Events & Rituals",
    subtitle: "मंदिर आयोजन",
    description: "Sacred ceremonies including Puja, Havans, Temple inaugurations, and religious festivals.",
    features: ["Priest Services", "Puja Materials", "Prasad Arrangement", "Devotional Music"],
    image: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?w=800&h=600&fit=crop",
    color: "from-primary to-accent",
  },
];

const Events = () => {
  return (
    <div className="min-h-screen pt-24">
      {/* Hero */}
      <section className="py-16 bg-gradient-to-br from-background via-muted to-background relative overflow-hidden">
        <div className="absolute inset-0 mandala-bg opacity-30" />
        <div className="container mx-auto px-4 text-center relative z-10">
          <span className="inline-block px-4 py-1 rounded-full bg-secondary/10 text-secondary text-sm font-medium mb-4">
            Our Events
          </span>
          <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            <span className="text-foreground">Cultural</span>{" "}
            <span className="gradient-gold-text">Celebrations</span>
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            From intimate ceremonies to grand festivals, we bring authenticity and elegance to every cultural celebration.
          </p>
        </div>
      </section>

      {/* Events Grid */}
      <section className="py-20 bg-card paisley-pattern">
        <div className="container mx-auto px-4">
          <div className="space-y-16">
            {events.map((event, index) => (
              <div
                key={event.title}
                className={`grid lg:grid-cols-2 gap-8 items-center ${
                  index % 2 === 1 ? "lg:flex-row-reverse" : ""
                }`}
              >
                <div className={`${index % 2 === 1 ? "lg:order-2" : ""}`}>
                  <div className="relative group">
                    <div className="aspect-[4/3] rounded-2xl overflow-hidden border-4 border-secondary/20 shadow-gold">
                      <img
                        src={event.image}
                        alt={event.title}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      />
                      <div className={`absolute inset-0 bg-gradient-to-t ${event.color} opacity-30`} />
                    </div>
                    {/* Decorative corners */}
                    <div className="absolute -top-3 -left-3 w-10 h-10 border-t-4 border-l-4 border-secondary rounded-tl-lg" />
                    <div className="absolute -bottom-3 -right-3 w-10 h-10 border-b-4 border-r-4 border-secondary rounded-br-lg" />
                  </div>
                </div>

                <div className={`${index % 2 === 1 ? "lg:order-1" : ""}`}>
                  <div className="flex items-center gap-3 mb-4">
                    <div className={`w-14 h-14 rounded-full bg-gradient-to-br ${event.color} flex items-center justify-center shadow-gold`}>
                      <event.icon className="w-7 h-7 text-primary-foreground" />
                    </div>
                    <div>
                      <h2 className="font-display text-2xl md:text-3xl font-bold text-foreground">
                        {event.title}
                      </h2>
                      <p className="text-secondary font-medium">{event.subtitle}</p>
                    </div>
                  </div>

                  <p className="text-muted-foreground mb-6 leading-relaxed">
                    {event.description}
                  </p>

                  <div className="grid grid-cols-2 gap-3 mb-6">
                    {event.features.map((feature) => (
                      <div key={feature} className="flex items-center gap-2">
                        <Check className="w-5 h-5 text-secondary" />
                        <span className="text-sm text-muted-foreground">{feature}</span>
                      </div>
                    ))}
                  </div>

                  <Link to="/contact">
                    <Button variant="gold">
                      Inquire Now
                      <ArrowRight className="w-5 h-5" />
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-primary to-accent text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
            Ready to Plan Your Event?
          </h2>
          <p className="text-primary-foreground/80 mb-8 max-w-xl mx-auto">
            Let our experts help you create a celebration that honors your traditions.
          </p>
          <Link to="/contact">
            <Button variant="gold" size="xl">
              Get Started
              <ArrowRight className="w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Events;
