import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Phone, Mail, MapPin, Clock, Send, Sparkles } from "lucide-react";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    eventType: "",
    date: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Thank you! We'll get back to you within 24 hours.", {
      description: "Our team is excited to help plan your celebration.",
    });
    setFormData({
      name: "",
      email: "",
      phone: "",
      eventType: "",
      date: "",
      message: "",
    });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const contactInfo = [
    {
      icon: Phone,
      title: "Phone",
      value: "+91 98765 43210",
      link: "tel:+919876543210",
    },
    {
      icon: Mail,
      title: "Email",
      value: "namaste@sanskritik.com",
      link: "mailto:namaste@sanskritik.com",
    },
    {
      icon: MapPin,
      title: "Address",
      value: "123 Heritage Lane, Mumbai, Maharashtra 400001",
      link: "#",
    },
    {
      icon: Clock,
      title: "Hours",
      value: "Mon - Sat: 10AM - 7PM",
      link: "#",
    },
  ];

  const eventTypes = [
    "Wedding Ceremony",
    "Engagement Ceremony",
    "Cultural Festival",
    "Traditional Dance Show",
    "Temple Event",
    "Corporate Event",
    "Other",
  ];

  return (
    <div className="min-h-screen pt-24">
      {/* Hero */}
      <section className="py-16 bg-gradient-to-br from-background via-muted to-background relative overflow-hidden">
        <div className="absolute inset-0 mandala-bg opacity-30" />
        <div className="container mx-auto px-4 text-center relative z-10">
          <span className="inline-block px-4 py-1 rounded-full bg-secondary/10 text-secondary text-sm font-medium mb-4">
            Get In Touch
          </span>
          <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            <span className="text-foreground">Plan Your</span>{" "}
            <span className="gradient-gold-text">Celebration</span>
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Share your vision with us, and let's create something beautiful together.
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-card">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div className="bg-background rounded-2xl border-2 border-secondary/20 p-8 shadow-soft">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-secondary to-gold-dark flex items-center justify-center shadow-gold">
                  <Sparkles className="w-6 h-6 text-secondary-foreground" />
                </div>
                <div>
                  <h2 className="font-display text-2xl font-bold text-foreground">Inquiry Form</h2>
                  <p className="text-muted-foreground text-sm">Tell us about your event</p>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Your Name *
                    </label>
                    <Input
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="Enter your full name"
                      required
                      className="border-secondary/30 focus:border-secondary"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Phone Number *
                    </label>
                    <Input
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      placeholder="+91 00000 00000"
                      required
                      className="border-secondary/30 focus:border-secondary"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Email Address *
                  </label>
                  <Input
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="your@email.com"
                    required
                    className="border-secondary/30 focus:border-secondary"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Event Type *
                    </label>
                    <select
                      name="eventType"
                      value={formData.eventType}
                      onChange={handleChange}
                      required
                      className="w-full h-11 rounded-xl border border-secondary/30 bg-background px-4 text-foreground focus:border-secondary focus:ring-1 focus:ring-secondary outline-none"
                    >
                      <option value="">Select event type</option>
                      {eventTypes.map((type) => (
                        <option key={type} value={type}>{type}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Preferred Date
                    </label>
                    <Input
                      name="date"
                      type="date"
                      value={formData.date}
                      onChange={handleChange}
                      className="border-secondary/30 focus:border-secondary"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Tell Us More
                  </label>
                  <Textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Share your vision, requirements, and any specific details..."
                    rows={5}
                    className="border-secondary/30 focus:border-secondary"
                  />
                </div>

                <Button type="submit" variant="gold" size="lg" className="w-full">
                  <Send className="w-5 h-5" />
                  Send Inquiry
                </Button>
              </form>
            </div>

            {/* Contact Info */}
            <div>
              <h2 className="font-display text-2xl font-bold text-foreground mb-6">
                Contact Information
              </h2>

              <div className="space-y-6 mb-10">
                {contactInfo.map((info) => (
                  <a
                    key={info.title}
                    href={info.link}
                    className="flex items-start gap-4 p-4 rounded-xl bg-background border border-secondary/20 hover:border-secondary/50 hover:shadow-gold transition-all duration-300"
                  >
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-secondary/20 to-gold-dark/20 flex items-center justify-center flex-shrink-0">
                      <info.icon className="w-6 h-6 text-secondary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">{info.title}</h3>
                      <p className="text-muted-foreground">{info.value}</p>
                    </div>
                  </a>
                ))}
              </div>

              {/* Map placeholder */}
              <div className="rounded-2xl overflow-hidden border-2 border-secondary/20 h-64 bg-muted flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="w-12 h-12 text-secondary mx-auto mb-2" />
                  <p className="text-muted-foreground">Interactive Map</p>
                  <p className="text-sm text-muted-foreground">Mumbai, Maharashtra</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Preview */}
      <section className="py-20 bg-background texture-paper">
        <div className="container mx-auto px-4 text-center">
          <h2 className="font-display text-3xl font-bold mb-8">
            <span className="text-foreground">Frequently Asked</span>{" "}
            <span className="gradient-gold-text">Questions</span>
          </h2>

          <div className="max-w-2xl mx-auto space-y-4">
            {[
              { q: "How far in advance should I book?", a: "We recommend booking 3-6 months in advance for large events, and at least 1 month for smaller ceremonies." },
              { q: "Do you handle events outside Mumbai?", a: "Yes! We organize events across India and have experience with destination celebrations." },
              { q: "Can you customize packages?", a: "Absolutely! Every event is unique, and we tailor our services to match your specific requirements." },
            ].map((faq, index) => (
              <div key={index} className="text-left p-6 rounded-xl bg-card border border-secondary/20">
                <h3 className="font-semibold text-foreground mb-2">{faq.q}</h3>
                <p className="text-muted-foreground">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
