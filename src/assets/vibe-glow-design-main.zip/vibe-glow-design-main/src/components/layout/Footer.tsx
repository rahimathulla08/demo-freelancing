import { Link } from "react-router-dom";
import { Sparkles, Instagram, Facebook, Youtube, Phone, Mail, MapPin } from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const socialLinks = [
    { icon: Instagram, href: "#", label: "Instagram" },
    { icon: Facebook, href: "#", label: "Facebook" },
    { icon: Youtube, href: "#", label: "YouTube" },
  ];

  const quickLinks = [
    { name: "Home", href: "/" },
    { name: "Events", href: "/events" },
    { name: "Services", href: "/services" },
    { name: "Gallery", href: "/gallery" },
    { name: "About", href: "/about" },
    { name: "Contact", href: "/contact" },
  ];

  const eventTypes = [
    "Wedding Ceremonies",
    "Cultural Festivals",
    "Traditional Dance",
    "Temple Events",
    "Corporate Events",
    "Engagement Rituals",
  ];

  return (
    <footer className="relative overflow-hidden bg-primary text-primary-foreground">
      {/* Decorative pattern top */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-secondary to-transparent" />
      
      {/* Mandala watermark */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] opacity-5">
        <svg viewBox="0 0 200 200" className="w-full h-full">
          <circle cx="100" cy="100" r="90" fill="none" stroke="currentColor" strokeWidth="0.5"/>
          <circle cx="100" cy="100" r="70" fill="none" stroke="currentColor" strokeWidth="0.5"/>
          <circle cx="100" cy="100" r="50" fill="none" stroke="currentColor" strokeWidth="0.5"/>
          <circle cx="100" cy="100" r="30" fill="none" stroke="currentColor" strokeWidth="0.5"/>
          {[...Array(12)].map((_, i) => (
            <line key={i} x1="100" y1="10" x2="100" y2="190" stroke="currentColor" strokeWidth="0.3" transform={`rotate(${i * 30} 100 100)`}/>
          ))}
        </svg>
      </div>

      <div className="relative z-10 pt-16 pb-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
            {/* Brand */}
            <div>
              <Link to="/" className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-secondary to-gold-dark flex items-center justify-center shadow-gold">
                  <Sparkles className="w-6 h-6 text-secondary-foreground" />
                </div>
                <div>
                  <span className="font-display font-bold text-xl text-secondary block leading-tight">
                    सांस्कृतिक
                  </span>
                  <span className="text-xs text-primary-foreground/70 tracking-widest uppercase">
                    Cultural Events
                  </span>
                </div>
              </Link>
              <p className="text-primary-foreground/80 mb-6 font-elegant text-lg italic">
                "Celebrating traditions, creating memories that last generations."
              </p>
              <div className="flex gap-3">
                {socialLinks.map((social) => (
                  <a
                    key={social.label}
                    href={social.href}
                    aria-label={social.label}
                    className="w-10 h-10 rounded-full bg-primary-foreground/10 flex items-center justify-center hover:bg-secondary hover:text-secondary-foreground transition-all duration-300"
                  >
                    <social.icon className="w-5 h-5" />
                  </a>
                ))}
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="font-display font-semibold text-lg mb-6 text-secondary">Quick Links</h3>
              <ul className="space-y-3">
                {quickLinks.map((link) => (
                  <li key={link.name}>
                    <Link
                      to={link.href}
                      className="text-primary-foreground/80 hover:text-secondary transition-colors duration-300"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Event Types */}
            <div>
              <h3 className="font-display font-semibold text-lg mb-6 text-secondary">Our Events</h3>
              <ul className="space-y-3">
                {eventTypes.map((event) => (
                  <li key={event}>
                    <span className="text-primary-foreground/80">{event}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h3 className="font-display font-semibold text-lg mb-6 text-secondary">Contact Us</h3>
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-secondary mt-0.5 flex-shrink-0" />
                  <span className="text-primary-foreground/80">
                    123 Heritage Lane,<br />
                    Mumbai, Maharashtra 400001
                  </span>
                </li>
                <li>
                  <a
                    href="mailto:namaste@sanskritik.com"
                    className="flex items-center gap-3 text-primary-foreground/80 hover:text-secondary transition-colors duration-300"
                  >
                    <Mail className="w-5 h-5 flex-shrink-0" />
                    namaste@sanskritik.com
                  </a>
                </li>
                <li>
                  <a
                    href="tel:+919876543210"
                    className="flex items-center gap-3 text-primary-foreground/80 hover:text-secondary transition-colors duration-300"
                  >
                    <Phone className="w-5 h-5 flex-shrink-0" />
                    +91 98765 43210
                  </a>
                </li>
              </ul>
            </div>
          </div>

          {/* Divider */}
          <div className="h-px bg-gradient-to-r from-transparent via-secondary/50 to-transparent mb-8" />

          {/* Bottom bar */}
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-primary-foreground/60 text-sm">
              © {currentYear} Sanskritik Cultural Events. All rights reserved.
            </p>
            <p className="text-primary-foreground/60 text-sm font-elegant italic">
              Made with ♥ for preserving traditions
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
