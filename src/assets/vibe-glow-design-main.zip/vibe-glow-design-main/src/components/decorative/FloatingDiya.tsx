const FloatingDiya = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Floating Diyas */}
      {[...Array(5)].map((_, i) => (
        <div
          key={i}
          className="absolute animate-float-slow"
          style={{
            left: `${15 + i * 20}%`,
            top: `${20 + (i % 3) * 25}%`,
            animationDelay: `${i * 1.5}s`,
          }}
        >
          <div className="relative">
            {/* Diya base */}
            <div className="w-8 h-4 bg-gradient-to-r from-secondary to-gold-dark rounded-full shadow-gold" />
            {/* Flame */}
            <div className="absolute -top-4 left-1/2 -translate-x-1/2">
              <div className="w-2 h-4 bg-gradient-to-t from-accent via-secondary to-transparent rounded-full animate-diya opacity-80" />
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-4 h-6 bg-accent/20 rounded-full blur-md" />
            </div>
          </div>
        </div>
      ))}

      {/* Floating flower petals */}
      {[...Array(8)].map((_, i) => (
        <div
          key={`petal-${i}`}
          className="absolute w-3 h-3 rounded-full animate-petal opacity-60"
          style={{
            left: `${10 + i * 12}%`,
            backgroundColor: i % 2 === 0 ? 'hsl(350, 70%, 60%)' : 'hsl(25, 90%, 65%)',
            animationDelay: `${i * 1.2}s`,
            animationDuration: `${8 + i}s`,
          }}
        />
      ))}

      {/* Mandala circles */}
      <div className="absolute top-10 right-10 w-32 h-32 opacity-10">
        <svg viewBox="0 0 100 100" className="w-full h-full animate-spin" style={{ animationDuration: '30s' }}>
          <circle cx="50" cy="50" r="45" fill="none" stroke="hsl(43, 85%, 50%)" strokeWidth="0.5" strokeDasharray="5,5"/>
          <circle cx="50" cy="50" r="35" fill="none" stroke="hsl(43, 85%, 50%)" strokeWidth="0.5"/>
          <circle cx="50" cy="50" r="25" fill="none" stroke="hsl(43, 85%, 50%)" strokeWidth="0.5" strokeDasharray="3,3"/>
        </svg>
      </div>

      <div className="absolute bottom-20 left-10 w-24 h-24 opacity-10">
        <svg viewBox="0 0 100 100" className="w-full h-full animate-spin" style={{ animationDuration: '25s', animationDirection: 'reverse' }}>
          <circle cx="50" cy="50" r="45" fill="none" stroke="hsl(350, 70%, 50%)" strokeWidth="0.5"/>
          <circle cx="50" cy="50" r="30" fill="none" stroke="hsl(350, 70%, 50%)" strokeWidth="0.5" strokeDasharray="8,4"/>
        </svg>
      </div>
    </div>
  );
};

export default FloatingDiya;
